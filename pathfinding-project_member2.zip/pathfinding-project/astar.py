"""astar.py - PLACEHOLDER reference version for integration testing.

Member 3 owns this file and should replace it with their own implementation.
It must keep the same function name and return format (see INTERFACE.md).
"""
import heapq
import time


def manhattan(a, b):
    return abs(a[0] - b[0]) + abs(a[1] - b[1])


def solve(grid, start, goal):
    t0 = time.perf_counter()
    g = {start: 0}
    prev = {}
    explored = []
    done = set()
    pq = [(manhattan(start, goal), 0, start)]
    found = False
    while pq:
        _, gc, cell = heapq.heappop(pq)
        if cell in done:
            continue
        done.add(cell)
        explored.append(cell)
        if cell == goal:
            found = True
            break
        for nb in grid.neighbors(*cell):
            ng = gc + grid.MOVE_COST
            if ng < g.get(nb, float("inf")):
                g[nb] = ng
                prev[nb] = cell
                heapq.heappush(pq, (ng + manhattan(nb, goal), ng, nb))
    path = []
    if found:
        cell = goal
        while cell != start:
            path.append(cell)
            cell = prev[cell]
        path.append(start)
        path.reverse()
    return {
        "found": found,
        "path": path,
        "cost": g[goal] if found else None,
        "nodes_expanded": len(explored),
        "time": time.perf_counter() - t0,
        "explored": explored,
    }
