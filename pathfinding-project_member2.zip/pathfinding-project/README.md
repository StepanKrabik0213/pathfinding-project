# Humanitarian Route Planner: Dijkstra vs A* (CSCI218 Topic 8)

Finds the shortest route on a 2D grid from a start (Dubai) to a goal (a crisis
destination) when some cells are unavailable (closed airports, ports or roads).
Compares Dijkstra's algorithm and A* search on execution time, nodes expanded
and path cost. The map is an illustrative model, not real operational data.

## Requirements
- Python 3.10 or newer
- pygame (grid window), pytest (tests)

## Install
```bash
git clone <repository-url>
cd pathfinding-project
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

## Run the simulation
```bash
python main.py
```
| Control | Action |
|---|---|
| Click / drag on grid (Wall tool) | Block or unblock cells |
| Start / Goal tool, then click | Move the start or goal |
| Run Dijkstra / Run A* / Run both (keys 1, 2, 3) | Search and show result |
| Switch view | Toggle between the two algorithms' results |
| Clear path (C) | Remove results, keep the map |
| Reset grid | Open all cells |
| Scenario map (S), Unreachable demo | Built-in maps |
| New random map (N), Density -/+, Size | Random layouts (10/20/30/40%, 10x10, 25x25, 50x50) |

Colours: green = start, red = goal, dark = closed route, blue/green tint = explored
cells (Dijkstra/A*), orange = final path. Each result card shows whether a path was
found, its cost, nodes expanded and time.

## Run the tests
```bash
python -m pytest tests
```

## Project layout
| File | Owner |
|---|---|
| `main.py`, `grid.py`, `README.md`, `requirements.txt`, `INTERFACE.md` | Member 1 |
| `dijkstra.py`, `tests/test_dijkstra.py`, `dijkstra_benchmark.py` | Member 2 |
| `astar.py` | Member 3 (placeholder until replaced) |
| `experiments.py`, `results/` | Member 4 |

Module instructions from Members 2 to 4:

**Member 2, Dijkstra (`dijkstra.py`).** Final version, follows `INTERFACE.md`.
- Use it directly: `import dijkstra; res = dijkstra.solve(grid, grid.start, grid.goal)`
- Unit tests: `python -m pytest tests/test_dijkstra.py -v` (57 tests)
- Record metrics: `python dijkstra_benchmark.py` writes `results/dijkstra_metrics.csv`
  (10x10 to 100x100, 10/20/30% obstacles, 10 seeded maps each, median of 5 timings)
- Report figures: `python report/m2_figures.py` (saved in `report/screenshots_m2/`)

**[TEAM: Members 3 and 4 add notes here]**

## Screenshots
Headless screenshots for the report: `python main.py --screenshot out.png --map scenario --algo astar`
(`--map scenario|unreachable|random`, `--algo dijkstra|astar|both|none`).
